

package pack;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
@Entity
@Table(name="tbl_city")
public class Bean_City  implements Serializable
{
    @Id
    int city_id;
    String city_name;
    int is_del;

    public int getCity_id() {
        return city_id;
    }

    public void setCity_id(int city_id) {
        this.city_id = city_id;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public int getIs_del() {
        return is_del;
    }

    public void setIs_del(int is_del) {
        this.is_del = is_del;
    }
   public List displayAllCity()
   {
        SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
        List l=s.createQuery("from Bean_City").list();
        s.close();
        return l;
   }
   public String getCityNameValue()
   {
        SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
        List l=s.createQuery("select bc.city_name from Bean_City bc where bc.city_id="+city_id).list();
       Iterator it=l.iterator();
       if(it.hasNext())
       {
         city_name=  it.next().toString();
       }
       
       s.close();
       return city_name;
   }
   public boolean updateCityName()
   {
       SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        s.saveOrUpdate(this);
        t.commit();
        s.close();
        return true;
       
   }
   public boolean deleteCityName()
   {
      SessionFactory sf=NewHibernateUtil.getSessionFactory();
     Session s= sf.openSession();
       Transaction t=s.beginTransaction();
        s.delete(this);
        t.commit();
        s.close();
        return true;
   }
   public String checkCityName(String str)
   {  
      SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
      List l= s.createQuery("select bc.city_name from Bean_City bc where bc.city_name='"+str+"'").list();
   Iterator it=   l.iterator();
     if(it.hasNext())
         return "y";
     else
         return "n";
   
   }
    
   public void  getRecord()
   {
   SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
        Bean_City bn=(Bean_City)s.get(Bean_City.class, city_id);
        this.city_name=bn.city_name;
   }
   public int getCityid(String str)
   {
       int id=0;
      SessionFactory sf=NewHibernateUtil.getSessionFactory();
        Session s=sf.openSession();
       List l=    s.createQuery("select bc.city_id from Bean_City bc where bc.city_name='"+str+"'").list();
       Iterator it=  l.iterator();
       if(it.hasNext())
       {
    id=  Integer.parseInt(it.next().toString());
           
       }
       s.close();
       return id;
   }
   
}
