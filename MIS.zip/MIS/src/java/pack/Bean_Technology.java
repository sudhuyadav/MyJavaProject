/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_technology")
public class Bean_Technology implements Serializable{
    @Id
    int technology_id;
    String technology_name;
    String technology_duration;
    String technology_fee;

    public int getTechnology_id() {
        return technology_id;
    }

    public void setTechnology_id(int technology_id) {
        this.technology_id = technology_id;
    }

    public String getTechnology_name() {
        return technology_name;
    }

    public void setTechnology_name(String technology_name) {
        this.technology_name = technology_name;
    }

    public String getTechnology_duration() {
        return technology_duration;
    }

    public void setTechnology_duration(String technology_duration) {
        this.technology_duration = technology_duration;
    }

    public String getTechnology_fee() {
        return technology_fee;
    }

    public void setTechnology_fee(String technology_fee) {
        this.technology_fee = technology_fee;
    }
   
    
}
