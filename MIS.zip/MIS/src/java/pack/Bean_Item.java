
package pack;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@Entity
@Table(name="tbl_items")
public class Bean_Item implements Serializable{
 @Id
 int item_id;
 String item_name;
int is_del;
    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public int getIs_del() {
        return is_del;
    }

    public void setIs_del(int is_del) {
        this.is_del = is_del;
    }
 
    public boolean insertItems()
    {
   SessionFactory sf=    NewHibernateUtil.getSessionFactory();
    Session s= sf.openSession();
   Transaction tx=   s.beginTransaction();
   s.saveOrUpdate(this);
   tx.commit();
   s.close();;
   return true;
    }
    public List getItemsValue()
    {
       SessionFactory sf=    NewHibernateUtil.getSessionFactory();
    Session s= sf.openSession(); 
    List l=  s.createQuery("from Bean_Item").list();
    s.close();
    return l;
    }
 
}
