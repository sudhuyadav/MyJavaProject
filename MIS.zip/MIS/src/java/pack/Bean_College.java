/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@Entity
@Table(name="tbl_college")
public class Bean_College  implements Serializable{
@Id
int college_id;
String college_name;
int city_name;
String contact_person;
String remark;

    public int getCollege_id() {
        return college_id;
    }

    public void setCollege_id(int college_id) {
        this.college_id = college_id;
    }

    public String getCollege_name() {
        return college_name;
    }

    public void setCollege_name(String college_name) {
        this.college_name = college_name;
    }

    public int getCity_name() {
        return city_name;
    }

    public void setCity_name(int city_name) {
        this.city_name = city_name;
    }

    public String getContact_person() {
        return contact_person;
    }

    public void setContact_person(String contact_person) {
        this.contact_person = contact_person;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
     
    public List showCollege()
    {
        SessionFactory sf=NewHibernateUtil.getSessionFactory();
       Session s= sf.openSession();
            List l= s.createQuery("from Bean_College").list();
          s.close();
          return l;
        
    }
    public String showRecordCollege(int a)
    {    String colln="";
         String cn="";
         String cp="";
         String rm="";
           SessionFactory sf=NewHibernateUtil.getSessionFactory();
       Session s= sf.openSession();
            List l= s.createQuery("from Bean_College bc where bc.college_id="+a).list();
       Iterator it=  l.iterator();
       if(it.hasNext())
       {
     Bean_College   bc= (Bean_College)it.next();
       colln=  bc.getCollege_name();
         cn=    bc.getCity_name()+"";
           cp=  bc.getContact_person();
           rm= bc.getRemark();
       }
       String str=colln+"//"+cn+"//"+cp+"//"+rm;
            
            s.close();
    return str;
    
    }
    public boolean updateCollege()
    {
    SessionFactory sf=NewHibernateUtil.getSessionFactory();
       Session s= sf.openSession();
          Transaction tx= s.beginTransaction();
             s.saveOrUpdate(this);
             tx.commit();
             s.close();
             return true;
    
    }
    public boolean deleteCollege()
    {
    SessionFactory sf=    NewHibernateUtil.getSessionFactory();
    Session s=  sf.openSession();
   Transaction tx= s.beginTransaction();
   s.delete(this);
   tx.commit();
   s.close();
   return true;
    }
    
    
    

}
