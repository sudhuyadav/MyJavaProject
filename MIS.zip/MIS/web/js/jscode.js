	var i=0;
		var count=0;
		$(document).ready(function(){
		$(".nbtn").click(function(){
		i++;
		//alert(i);
		if(i==1)
		{
			$(".pbtn").show();
		}
		 $.ajax({
	    type:"post",
		url:"test_code.php",
		data:"id="+i,
		success:function(result){
		//alert(result);
		$(".outer").html(result);
		}
	 }); 
		});
		$(".pbtn").click(function(){
		i--;
		//alert(i);
		if(i>1)
		{ 
			$(".pbtn").hide();
		}
		 $.ajax({
	    type:"post",
		url:"test_code.php",
		data:"id="+i,
		success:function(result){
		//alert(result);
		$(".outer").html(result);
		}
	 }); 
		});
		});
	 //alert(name)
		function chk(o){
			var r=$(o);
			var ra=$(o).val();
				//alert(ra);
				var a=$(".ans").val();
				//alert(a);
				if(ra==a)
				{
						count++;
					$(".result").html("Correct"+count);
                    //$(".result").css("background","orange");
				
				}
				else
				{
					$(".result").html("InCorrect");
                   // count=count;
                   //  $(".result").css("background","red");
				}
			}
			